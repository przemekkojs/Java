package Zadanie2;

//Niedokonczone...
public class Main2 
{
	public static void main(String[] args) 
	{
		Write.WriteToFile("output.txt");
		Read.ReadFromFile("output.txt");
	}
}