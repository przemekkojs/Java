public class Przemyslaw_Kojs_Zadanie2 
{	
	public static void main(String[] args) 
	{
		Przemyslaw_Kojs_Tab tab = new Przemyslaw_Kojs_Tab(5);
		
		tab.Fill(10);
		tab.Show(tab.tab);
		tab.Show(tab.Convert());
	}
}